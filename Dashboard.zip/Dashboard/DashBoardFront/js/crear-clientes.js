let nombreCliente=document.querySelector("");
let apellidoCliente=document.querySelector("");
let emailCliente=document.querySelector("");
let celularCliente=document.querySelector("");
let direccionCliente1=document.querySelector("");
let direccionCliente2=document.querySelector("");
let descripcionCliente=document.querySelector("");
let btnGuardar=document.querySelector("");